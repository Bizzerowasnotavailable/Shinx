﻿using System;
using Sys = Cosmos.System;
using System.Drawing;
using Cosmos.System.Graphics;
using CMouse = Cosmos.System.MouseManager;

namespace Shinx.GUI
{
    public static class Mouse
    {
        private static bool _wasPressed = false;
        private static bool _frameClick = false;

        private static Color mousePen = Color.White;
        private static Color borderPen = Color.Black;

        private static int[][] cursorShape = new int[][] {
            new int[] {0, 1}, new int[] {0, 2}, new int[] {0, 3}, new int[] {0, 4},
            new int[] {0, 5}, new int[] {0, 6}, new int[] {0, 7}, new int[] {0, 8},
            new int[] {0, 5}, new int[] {0, 2}, new int[] {1, 2}, new int[] {2, 2},
            new int[] {3, 2}
        };

        public static void UpdateState()
        {
            bool currentlyPressed = (CMouse.MouseState == Sys.MouseState.Left);

            _frameClick = (currentlyPressed && !_wasPressed);

            _wasPressed = currentlyPressed;
        }

        public static bool Click()
        {
            return _frameClick;
        }

        public static bool IsPressed()
        {
            return CMouse.MouseState == Sys.MouseState.Left;
        }

        public static void DrawMouse(Canvas vbe, int x, int y)
        {
            DrawCursorInternal(vbe, x + 1, y + 1, borderPen);
            DrawCursorInternal(vbe, x, y, mousePen);
        }

        private static void DrawCursorInternal(Canvas vbe, int x, int y, Color color)
        {
            for (int i = 0; i < cursorShape.Length; i++)
            {
                vbe.DrawLine(color, x + cursorShape[i][0], y + i, x + cursorShape[i][1], y + i);
            }
        }
    }
}