﻿using System;
using System.Collections.Generic;

namespace Shinx.Commands
{
    public class core_sha256 : ICommand
    {
        private static readonly uint[] K = new uint[]
        {
            0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
        };

        public void Execute(string[] args, HashSet<char> parameters)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("usage: sha256sum <string>");
                return;
            }
            Console.WriteLine(Hash(args[0]));
        }

        public static string Hash(string input)
        {
            byte[] msg = new byte[input.Length];
            for (int i = 0; i < input.Length; i++)
                msg[i] = (byte)input[i];

            return HashBytes(msg);
        }

        public static string HashBytes(byte[] msg)
        {
            uint[] h = new uint[]
            {
                0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
            };

            int origLen = msg.Length;
            int newLen = origLen + 1;
            while (newLen % 64 != 56) newLen++;
            newLen += 8;

            byte[] padded = new byte[newLen];
            for (int i = 0; i < origLen; i++)
                padded[i] = msg[i];

            padded[origLen] = 0x80;

            ulong bitLen = (ulong)origLen * 8;
            for (int i = 0; i < 8; i++)
                padded[newLen - 1 - i] = (byte)(bitLen >> (i * 8));

            for (int chunk = 0; chunk < newLen / 64; chunk++)
            {
                uint[] w = new uint[64];
                for (int i = 0; i < 16; i++)
                {
                    w[i] = ((uint)padded[chunk * 64 + i * 4] << 24) |
                            ((uint)padded[chunk * 64 + i * 4 + 1] << 16) |
                            ((uint)padded[chunk * 64 + i * 4 + 2] << 8) |
                            ((uint)padded[chunk * 64 + i * 4 + 3]);
                }
                for (int i = 16; i < 64; i++)
                {
                    uint s0 = RightRotate(w[i - 15], 7) ^ RightRotate(w[i - 15], 18) ^ (w[i - 15] >> 3);
                    uint s1 = RightRotate(w[i - 2], 17) ^ RightRotate(w[i - 2], 19) ^ (w[i - 2] >> 10);
                    w[i] = w[i - 16] + s0 + w[i - 7] + s1;
                }

                uint a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];

                for (int i = 0; i < 64; i++)
                {
                    uint S1 = RightRotate(e, 6) ^ RightRotate(e, 11) ^ RightRotate(e, 25);
                    uint ch = (e & f) ^ (~e & g);
                    uint temp1 = hh + S1 + ch + K[i] + w[i];
                    uint S0 = RightRotate(a, 2) ^ RightRotate(a, 13) ^ RightRotate(a, 22);
                    uint maj = (a & b) ^ (a & c) ^ (b & c);
                    uint temp2 = S0 + maj;

                    hh = g; g = f; f = e; e = d + temp1;
                    d = c; c = b; b = a; a = temp1 + temp2;
                }

                h[0] += a; h[1] += b; h[2] += c; h[3] += d;
                h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
            }

            string result = "";
            foreach (uint val in h)
                result += val.ToString("x8");
            return result;
        }
        private static uint RightRotate(uint x, int n)
        {
            return (x >> n) | (x << (32 - n));
        }
    }
}