﻿using IL2CPU.API.Attribs;

namespace Shinx
{
    public static class LuaResources
    {
        [ManifestResourceStream(ResourceName = "Shinx.LuaUtils.fetch.lua")]
        public static byte[] fetch;

        [ManifestResourceStream(ResourceName = "Shinx.LuaUtils.bunnysay.lua")]
        public static byte[] bunnysay;

        [ManifestResourceStream(ResourceName = "Shinx.LuaUtils.widget_demo.lua")]
        public static byte[] widget_demo;

        public static readonly (string Name, byte[] Data)[] AllFiles =
        {
            ("fetch.lua", fetch),
            ("bunnysay.lua", bunnysay),
            ("widget_demo.lua", widget_demo)
        };
    }
}