﻿shinx.register("$safeitemname$", function()
    local args = shinx.args()
    local parameters = shinx.params()

    shinx.print("Running $safeitemname$...")
end, "A new Shinx command")