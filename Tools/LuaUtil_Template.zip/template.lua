shinx.register("$safeitemname$", function(args, parameters)
    shinx.print("Running $safeitemname$...")
end, "$safeitemname$")
